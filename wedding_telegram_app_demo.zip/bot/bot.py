# Python Telegram bot
# O'rnatish: pip install pyTelegramBotAPI
import os, json, telebot
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton, WebAppInfo

TOKEN = os.getenv("BOT_TOKEN", "BOT_TOKENINGIZNI_SHU_YERGA_QO'YING")
WEBAPP_URL = os.getenv("WEBAPP_URL", "https://YOUR-DOMAIN.example/")

bot = telebot.TeleBot(TOKEN, parse_mode="HTML")

@bot.message_handler(commands=["start"])
def start(message):
    kb = InlineKeyboardMarkup()
    kb.add(InlineKeyboardButton("💍 To‘y taklifnomasini ochish", web_app=WebAppInfo(url=WEBAPP_URL)))
    bot.send_message(message.chat.id, "Assalomu alaykum! 💌\n\nTo‘y taklifnomasini ochish uchun quyidagi tugmani bosing:", reply_markup=kb)

@bot.message_handler(content_types=["web_app_data"])
def webapp_data(message):
    try:
        data = json.loads(message.web_app_data.data)
        name = data.get("name", "")
        attendance = "Albatta keladi ❤️" if data.get("attendance") == "yes" else "Kela olmaydi"
        guests = data.get("guests", "1")
        wish = data.get("message", "") or "—"
        text = (
            "💌 <b>Yangi mehmon javobi</b>\n\n"
            f"👤 Ism: <b>{name}</b>\n"
            f"📋 Javob: <b>{attendance}</b>\n"
            f"👥 Mehmonlar soni: <b>{guests}</b>\n"
            f"💬 Tilak: {wish}"
        )
        bot.send_message(message.chat.id, text)
    except Exception as e:
        bot.send_message(message.chat.id, "Javobni qayta yuborishda xatolik yuz berdi.")
        print(e)

print("Bot ishga tushdi...")
bot.infinity_polling()
